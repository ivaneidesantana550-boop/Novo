# RHZIN Otimizador

Projeto Android nativo em Kotlin + Jetpack Compose, preparado para compilar APK automaticamente pelo GitHub Actions.

## Gerar APK no GitHub

1. Crie um repositório no GitHub.
2. Envie todos os arquivos deste ZIP para a raiz do repositório.
3. Abra a aba **Actions** e habilite workflows, se solicitado.
4. O workflow `Android APK` compila o app a cada push.
5. Abra a execução concluída e baixe o artefato **RHZIN-Otimizador-apk**.
6. O arquivo dentro do artefato terá o nome `RHZIN-Otimizador.apk`.

## O que o app faz atualmente

- Dashboard em português com tema preto/vermelho.
- Exibe informações acessíveis do dispositivo, bateria e armazenamento.
- Executa verificações locais e apresenta um relatório.
- Botão único “Otimização completa • 1 toque” executa de uma vez as verificações locais e apresenta os próximos passos para ações que exigem autorização do usuário.
- Atalhos para configurações do Android que permitem ao usuário realizar ações manualmente.

## Limites reais do Android

O Android não permite que um aplicativo comum “limpe toda a RAM”, apague dados de outros aplicativos, aumente fisicamente a bateria ou controle todas as configurações. Este app não finge executar essas ações: informa os dados acessíveis e direciona o usuário às configurações quando necessário. Recursos extras podem exigir permissões especiais e variar por fabricante.

**Observação:** APK é para Android. iPhone não instala APK; para iPhone seria necessário um projeto separado para iOS, com distribuição pelas regras da Apple.
