package com.rhzin.otimizador

import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File
import java.util.Locale

private val Bg = Color(0xFF090909)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFFF3030)
private val Muted = Color(0xFFB8B8B8)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RhzinApp() }
    }
}

data class DeviceStats(
    val totalStorage: Long,
    val freeStorage: Long,
    val batteryPercent: Int,
    val charging: Boolean,
    val ramTotal: Long,
    val ramAvailable: Long
)

private fun readStats(context: Context): DeviceStats {
    val stat = StatFs(Environment.getDataDirectory().path)
    val total = stat.blockCountLong * stat.blockSizeLong
    val free = stat.availableBlocksLong * stat.blockSizeLong
    val batteryManager = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
    val level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
    val batteryStatus = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val status = batteryStatus?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
    val memory = android.app.ActivityManager.MemoryInfo()
    am.getMemoryInfo(memory)
    return DeviceStats(total, free, level, charging, memory.totalMem, memory.availMem)
}

private fun bytes(value: Long): String {
    val gb = value / (1024.0 * 1024.0 * 1024.0)
    return String.format(Locale.getDefault(), "%.1f GB", gb)
}

@Composable
fun RhzinApp() {
    val context = LocalContext.current
    var stats by remember { mutableStateOf(readStats(context)) }
    var running by remember { mutableStateOf(false) }
    var report by remember { mutableStateOf("Pronto para analisar seu dispositivo.") }
    var completed by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red,
            background = Bg,
            surface = Panel,
            onPrimary = Color.White,
            onBackground = Color.White,
            onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("RHZIN", color = Red, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("OTIMIZADOR", fontSize = 26.sp, fontWeight = FontWeight.Black)
                        Text("Painel de diagnóstico do dispositivo", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFF321010), shape = RoundedCornerShape(14.dp)) {
                        Text("PRO", color = Red, modifier = Modifier.padding(horizontal = 13.dp, vertical = 9.dp), fontWeight = FontWeight.Bold)
                    }
                }

                Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("STATUS DO DISPOSITIVO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(if (completed) "Análise concluída" else "Seu painel está pronto", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        LinearProgressIndicator(
                            progress = { (stats.totalStorage - stats.freeStorage).toFloat() / stats.totalStorage.coerceAtLeast(1L).toFloat() },
                            modifier = Modifier.fillMaxWidth().height(7.dp),
                            color = Red,
                            trackColor = Color.DarkGray
                        )
                        Text("${bytes(stats.totalStorage - stats.freeStorage)} usados de ${bytes(stats.totalStorage)}", color = Muted, fontSize = 12.sp)
                        Button(
                            onClick = {
                                running = true
                                // Executa uma sequência única de verificações e abre as telas adequadas
                                // para ações que exigem confirmação do usuário.
                                stats = readStats(context)
                                val checks = mutableListOf<String>()
                                checks += "✓ Armazenamento verificado: ${bytes(stats.freeStorage)} livres."
                                checks += "✓ Bateria verificada: ${stats.batteryPercent}%${if (stats.charging) " (carregando)" else ""}."
                                checks += "✓ RAM consultada: ${bytes(stats.ramAvailable)} disponíveis."
                                checks += "✓ Estado do armazenamento externo: ${if (Environment.getExternalStorageState() == Environment.MEDIA_MOUNTED) "disponível" else "não disponível"}."
                                checks += "✓ Diagnóstico local concluído."
                                checks += "➡ Para liberar espaço, abra a tela de armazenamento e revise arquivos sugeridos."
                                checks += "➡ Para economizar bateria, abra as configurações de bateria."
                                checks += "➡ Para revisar apps e permissões, abra as configurações do sistema."
                                checks += "ℹ Limpeza de dados de outros apps e encerramento global de processos não são permitidos a apps comuns. Nenhuma limpeza foi simulada."
                                report = checks.joinToString("\n\n")
                                completed = true
                                running = false
                            },
                            modifier = Modifier.fillMaxWidth().height(54.dp),
                            shape = RoundedCornerShape(15.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Red)
                        ) {
                            Icon(Icons.Default.CleaningServices, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text(if (running) "OTIMIZANDO..." else "OTIMIZAÇÃO COMPLETA • 1 TOQUE", fontWeight = FontWeight.Black)
                        }
                    }
                }

                Text("MONITORAMENTO", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("BATERIA", "${stats.batteryPercent}%", "Estado atual", Icons.Default.BatteryChargingFull, Modifier.weight(1f))
                    StatCard("ARMAZENAMENTO", bytes(stats.freeStorage), "Livre", Icons.Default.Storage, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("RAM DISPONÍVEL", bytes(stats.ramAvailable), "Estimativa do sistema", Icons.Default.Memory, Modifier.weight(1f))
                    StatCard("SEGURANÇA", "Configurar", "Revisar permissões", Icons.Default.Security, Modifier.weight(1f))
                }

                Text("FERRAMENTAS", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ToolButton("Abrir configurações de armazenamento", "Gerencie arquivos e libere espaço manualmente") {
                    context.startActivity(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
                }
                ToolButton("Abrir configurações de bateria", "Confira uso e opções de economia de energia") {
                    context.startActivity(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
                }
                ToolButton("Abrir configurações do sistema", "Acesse permissões, aplicativos e conectividade") {
                    context.startActivity(Intent(Settings.ACTION_SETTINGS))
                }

                Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("RELATÓRIO DE OTIMIZAÇÃO", fontWeight = FontWeight.Bold, color = Red)
                        Text(report, color = Muted, fontSize = 13.sp, lineHeight = 19.sp)
                    }
                }
                Text("RHZIN Otimizador • Ferramentas permitidas pelo Android", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(color = Panel, shape = RoundedCornerShape(18.dp), modifier = modifier) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Icon(icon, contentDescription = null, tint = Red)
            Text(title, color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Color.Gray, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ToolButton(title: String, description: String, onClick: () -> Unit) {
    Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(description, color = Muted, fontSize = 11.sp)
            }
            IconButton(onClick = onClick) {
                Icon(Icons.Default.Settings, contentDescription = "Abrir", tint = Red)
            }
        }
    }
}
